---
title: "License"
description: The "kitchen sink," if you will ... a page showing examples of type and page elements included in this template.
draft: false
# layout options are standard (default) or wide-body
layout: standard
show_title_as_headline: true
---

My [blog posts](/post/) are released under a [Creative Commons Attribution-ShareAlike 4.0 International License](http://creativecommons.org/licenses/by-sa/4.0/).

<center>
<i class="fab fa-creative-commons fa-2x"></i><i class="fab fa-creative-commons-by fa-2x"></i><i class="fab fa-creative-commons-sa fa-2x"></i>
</center>